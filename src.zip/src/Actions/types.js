export const REG='REG';
export const LOGIN='LOGIN';

// export const STOREPWD='STOREPWD';