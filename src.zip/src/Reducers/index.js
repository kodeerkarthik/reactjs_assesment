import {combineReducers} from 'redux';
import Register_reducer from './Register_reducer';

export default combineReducers ({
    Register_reducer,
});